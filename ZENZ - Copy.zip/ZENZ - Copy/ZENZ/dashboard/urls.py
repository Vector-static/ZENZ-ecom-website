from django.urls import path

from . import views

app_name = 'dasboard'

urlpatterns = [
    path('', views.index, name='index'),
]